package com.mygdx.game;



//todo: class relations and inheritance and shit
public class Nation 
{

}

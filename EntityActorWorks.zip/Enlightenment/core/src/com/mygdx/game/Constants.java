package com.mygdx.game;

public class Constants 
{
	//int worldheight = ;
	//int worldwidth = ;
}

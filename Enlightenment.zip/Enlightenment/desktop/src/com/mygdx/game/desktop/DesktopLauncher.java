	
package com.mygdx.game.desktop;

import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;
import com.mygdx.game.enlightenment;
import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.mygdx.game.*;



	
	public class DesktopLauncher {
		public static void main (String[] arg) {
			LwjglApplicationConfiguration config = new LwjglApplicationConfiguration();
			config.title = "Enlightenment";
			config.width = 1024;
			config.height = 768;
			//config.fullscreen = true;
			new LwjglApplication(new enlightenment(), config);
			
			
		}
		
}




/*

	
	package com.mygdx.game.desktop;


import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.mygdx.game.*;


	
	public class DesktopLauncher {
		public static void main (String[] arg) {
			LwjglApplicationConfiguration config = new LwjglApplicationConfiguration();
			new LwjglApplication(new enlightenment(), config);
			

			
		}
		
}
	*/
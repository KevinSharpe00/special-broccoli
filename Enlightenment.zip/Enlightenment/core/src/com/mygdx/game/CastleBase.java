package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.Touchable;

public class CastleBase extends MyActor 
{

	public CastleBase(Texture texture, final String actorName) 
	{
		super(texture, actorName);
		
		//addListener(new InputListener() {
		  //@Override
		  //public boolean touchDown(InputEvent event, float x, float y, int pointer, int button) {
			//Gdx.app.log("Touch down asset with name ", actorName);
			//MapScreen.movestate();
			//return true;
		  //}
		//});
	}
	
	
	public void spritePos(float x, float y){
		sprite.setPosition(x, y);
		//entitiy.move(x,y);
		setBounds(sprite.getX(), sprite.getY(), sprite.getWidth(), sprite.getHeight());
	  }
	 
	  @Override
	  public void act(float delta) {
		super.act(delta);
	  }
	 
	  @Override
	  public void draw(Batch batch, float parentAlpha) {
		sprite.draw(batch);
	  }

	
}
package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.Touchable;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton.ImageButtonStyle;

public class CastleBase extends MyActor 
{

	public CastleBase(Texture texture, final String actorName) 
	{
		super(texture, actorName);
		TextureAtlas atlas = new TextureAtlas("menusprites.txt");
		Skin skin = new Skin(atlas);
		
		//ImageButtonStyle personbutton = new ImageButtonStyle();
		//personbutton.up = skin.getDrawable("PersonButton");
		//personbutton.over = skin.getDrawable("PersonButton");
		//personbutton.down = skin.getDrawable("PersonButton");
		//personbutton.pressedOffsetX = 1;
		//personbutton.pressedOffsetY = -1; 
		final ImageButtonStyle personbutton = UImanager.configbutton(skin, "PersonButton");
		final ImageButtonStyle swordbutton = UImanager.configbutton(skin, "brownsword");
		final ImageButtonStyle hammerbutton = UImanager.configbutton(skin, "hammerbutton");
		addListener(new InputListener() {
		  @Override
		  public boolean touchDown(InputEvent event, float x, float y, int pointer, int button) 
		  {
			  
			  final ImageButton pbutton = new ImageButton(personbutton);
			  final ImageButton hbutton = new ImageButton(hammerbutton);
			  
			  MapScreen.stage.addActor(pbutton);
			  //player castle is always at set position, so this is done.
	            pbutton.setPosition(144,80);
	            pbutton.addListener(new ClickListener(){
	                @Override
	                public void clicked(InputEvent event, float x, float y) 
	                {
	                	pbutton.remove();
	                	hbutton.remove();
	                	
	                	final ImageButton sbutton = new ImageButton(swordbutton);
	                	
	                	
	                	MapScreen.stage.addActor(sbutton);
	    	            sbutton.setPosition(144,80);
	    	            sbutton.addListener(new ClickListener(){
	    	                @Override
	    	                public void clicked(InputEvent event, float x, float y) 
	    	                {
	    	                	sbutton.remove();
	    	                	Texture tex = new Texture(Gdx.files.internal("redswordman.png"));
	    	                	//MapScreen.mygame.AddSwordsman(MapScreen.mygame.map.tiles[1][1],"Player 1");
	    	                	MapScreen.mygame.AddEntity(20,5,3,MapScreen.mygame.map.tiles[7][2],"Player 1",tex);
	    	                	//Gdx.app.log("entitycounter is:", String.valueOf(MapScreen.mygame.entity_counter));       [MapScreen.mygame.entity_counter-1]
	    	                	EntityActor ea = new EntityActor(MapScreen.mygame.entities.get(MapScreen.mygame.entity_counter-1), "redswordguy" + String.valueOf(MapScreen.mygame.entity_counter-1));//MapScreen.mygame.entity_counter
	    	                	MapScreen.mapstage.addActor(ea);
	    	                	ea.unrestrictedMove(112,32);
	    	                }
	    	            });
	                	
	                	
	                }
	            });
			  
	            MapScreen.stage.addActor(hbutton);
	            hbutton.setPosition(144,32);
	            hbutton.addListener(new ClickListener(){
	                @Override
	                public void clicked(InputEvent event, float x, float y) 
	                {
	                	pbutton.remove();
	                	hbutton.remove();
	                	
	                }
	            });
	            
	            
	            
			return true;
		  }
		});
	}
	
	
	public void spritePos(float x, float y){
		sprite.setPosition(x, y);
		//entitiy.move(x,y);
		setBounds(sprite.getX(), sprite.getY(), sprite.getWidth(), sprite.getHeight());
	  }
	 
	  @Override
	  public void act(float delta) {
		super.act(delta);
	  }
	 
	  @Override
	  public void draw(Batch batch, float parentAlpha) {
		sprite.draw(batch);
	  }

	
}
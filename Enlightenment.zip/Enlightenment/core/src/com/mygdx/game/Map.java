package com.mygdx.game;
import java.util.*;


public class Map {
	
	Tile[][] tiles;
	int length;
	int height;
	
	
	Map(int i, int j)
	{
		tiles = new Tile[i][j];
		for(int n = 0; n < i; n++)
		{
			for(int m = 0; m < j; m++)
			{
				Tile t = new Tile(n, m , "plains");
				tiles[n][m] = t;
		
			}
		}
		height = i;
		length = j;
	}
	

}

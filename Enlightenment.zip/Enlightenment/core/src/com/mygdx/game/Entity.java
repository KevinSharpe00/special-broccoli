package com.mygdx.game;


//named 'entity' cause it might need to include walls or smthn idk
//basically just the unit class
public class Entity //does it extend or implement something?
{

	//todo
	
	
	
}

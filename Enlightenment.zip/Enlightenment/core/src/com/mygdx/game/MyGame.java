package com.mygdx.game;

public class MyGame {

	Map map;
	
	public MyGame()
	{
		map = new Map(10, 10);
	}
	
	public MyGame(int i, int j)
	{
		map = new Map(i, j);
	}
	
	/*
	 * adds a building to the specific tile
	 * 
	 * returns true if building is built
	 * returns false is invalid building
	 */
	boolean AddBuilding(String building, int ipos, int jpos)
	{
		return map.tiles[ipos][jpos].AddBuilding(building);
	}
	
	
	
	
	
	/*
	 * prints the map on the console
	 */
	public void MapPrint()
	{
		for(int n = 0; n < map.height; n++)
		{
			for(int m = 0; m < map.length; m++)
			{
				System.out.print(map.tiles[n][m].test);
			}
			System.out.println();
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}

package com.mygdx.game;

public class MyGame {

	Map map;
	Nation[] N = new Nation[4];
	public int turn;
	
	Entity[] entities = new Entity[100];
	int entity_counter;
	
	public MyGame()
	{
		map = new Map(10, 10);
		//
		Nation P1 = new Nation();
		Nation P2 = new Nation();
		Nation P3 = new Nation();
		Nation P4 = new Nation();
		N = new Nation[4];
		N[0] = P1;
		N[1] = P2;
		N[2] = P3;
		N[3] = P4;
		
		turn = 0;
		//
		
		
		
	}
	
	public MyGame(int i, int j)
	{
		map = new Map(i, j);
		N = new Nation[4];
		turn = 0;
	}
	
	/*
	 * adds a building to the specific tile
	 * 
	 * returns true if building is built
	 * returns false is invalid building
	 */
	boolean AddBuilding(String building, int ipos, int jpos)
	{
		return map.tiles[ipos][jpos].AddBuilding(building);
	}
	
	/*
	 * prints the map on the console
	 */
	public void MapPrint()
	{
		for(int n = 0; n < map.height; n++)
		{
			for(int m = 0; m < map.length; m++)
			{
				System.out.print(map.tiles[n][m].test);
			}
			System.out.println();
		}
	}
	
	/////////////new Entity Stuff
	
	public void EntityPrint(int l)
	{
		entities[l].printInfo();
	}
	
	public void AddEntity(double h, double d, int r, Tile p, String c)
	{
		Entity E = new Entity(h, d, r, p, c);
		entities[entity_counter] = E;
		entity_counter++;
	}
	
	public void MoveEntity(int l, Tile T)
	{
		entities[l].Move(T);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	/////////////new Nation stuff
	
	public void AddMoney(int m)
	{
		N[turn].AddMoney(m);
	}
	
	public void AddTechPoints(int t)
	{
		N[turn].AddTechPoints(t);
	}
	
	public void BuildBuilding(String b, int x, int y)
	{
		if(N[turn].Build(b) == true)
		{
			boolean e = map.tiles[x][y].AddBuilding(b);
			if(e == false)
			{
				System.out.println("Invalid");
			}
		}
		
	}
	
	public void Research(int tech)
	{
		N[turn].research(tech);
	}
	
	public void printinfo()
	{
		N[turn].printinfo();
	}
	
	
	public void ChangeTurn()
	{
		N[turn].endturn();
		turn++;
		if(turn == 4)
		{
			turn = 0;
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}

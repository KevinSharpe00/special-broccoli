<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="pixil-frame-0" tilewidth="16" tileheight="16" spacing="1" tilecount="930" columns="31">
 <image source="pixil-frame-0.png" width="536" height="523"/>
</tileset>

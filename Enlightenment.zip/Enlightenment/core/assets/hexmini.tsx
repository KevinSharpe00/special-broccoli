<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="hexmini" tilewidth="18" tileheight="18" tilecount="20" columns="5">
 <image source="hexmini.png" width="106" height="72"/>
</tileset>

package com.mygdx.game;


//named 'entity' cause it might need to include walls or smthn idk
//basically just the unit class
public class Entity //does it extend or implement something?
{
	double health;
	double damage;
	int movement;
	Tile position;
	String commander;
	
	public Entity(double h, double d, int r, Tile p, String c)
	{
		health = h;
		damage = d;
		movement = r;//just ignore for now
		position = p;
		commander = c;
	}
	
	boolean Move(Tile T)
	{
		boolean moved = false;
		
		position = T;
		return moved;
	}
	
	public void printInfo()
	{
		System.out.println();
		System.out.println("Health: " + health);
		System.out.println("Damage: " + damage);
		System.out.println("Movement: " + movement);
		position.getCoords();
		System.out.println("Commander: " + commander);
	}
	
	public String getCommander()
	{
		return commander;
	}
	
	public double getdamage()
	{
		return damage;
	}
	
	public Tile getpos()
	{
		return position;
	}
	
	public void hurt(double dmg)
	{
		health -= dmg;
	}
	
}

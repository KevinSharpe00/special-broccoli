package com.mygdx.game.desktop;


import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;
import com.mygdx.game.enlightenment;
import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.mygdx.game.*;
import java.lang.Object.*;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

/*
public class DesktopLauncher {
	public static void main (String[] arg) {
		LwjglApplicationConfiguration config = new LwjglApplicationConfiguration();
		new LwjglApplication(new visualEntity(), config);
*/
		

	public class DesktopLauncher {
		public static void main (String[] arg) {
			LwjglApplicationConfiguration config = new LwjglApplicationConfiguration();
			new LwjglApplication(new enlightenment(), config);
			
			MyGame g = new MyGame();
			g.MapPrint();
			
			Tile A = new Tile(1, 1);
			g.AddEntity(10, 2, 1, A, "P1");
			g.EntityPrint(0);
			
			Tile B = new Tile(16, 42);
			g.MoveEntity(0, B);
			g.EntityPrint(0);
			
			g.AddEntity(4, 4, 1, A, "P2");
			g.EntityPrint(1);
			
			g.MoveEntity(1, B);
			g.EntityPrint(0);
			g.EntityPrint(1);
			
			g.endTurnBattles();
			g.EntityPrint(0);
			g.EntityPrint(1);
			
			g.AddEntity(100, 100, 1, A, "P3");
			g.MoveEntity(2, B);
			g.EntityPrint(2);
			
			
			/*
			//nation test
			int x = 0;
			int y = 0;
			g.Research(3);//test poor
			g.BuildBuilding("church", x, y);
			
			g.AddTechPoints(1000);
			g.AddMoney(1000);
			
			g.Research(9);
			g.Research(6);
			g.Research(9);
			g.Research(9);//test repeat
			
			g.BuildBuilding("church", x, y);
			g.BuildBuilding("castle", x, y);
			g.BuildBuilding("castle", x, y);
			g.BuildBuilding("castle", x, y);
			g.BuildBuilding("castle", x, y);
			g.ChangeTurn();
			g.BuildBuilding("church", x, y);
			g.ChangeTurn();
			g.ChangeTurn();
			g.ChangeTurn();//full circle
			g.BuildBuilding("church", x, y);
			g.printinfo();
			*/
			
			
			
		}
		
}

package com.mygdx.game.desktop;


import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.mygdx.game.*;


	
	public class DesktopLauncher {
		public static void main (String[] arg) {
			LwjglApplicationConfiguration config = new LwjglApplicationConfiguration();
			new LwjglApplication(new enlightenment(), config);
			
		         
		     //Game_UI UI = new Game_UI();
		     //UI.createAndShowGUI();
		          
			
			
			MyGame g = new MyGame();
			g.MapPrint(); 
			
			//added for testing//////////////////////////////////////////////////////////////////////////////////////////////////////
			/*
			for(int i = 0; i< 5; i++) 
			{
				g.AddUnit(20.0, 5.0, 1, g.map.getTile(i, i), "Player 1", t );
			}
			g.render();
			*/
			
			
		}
		
}

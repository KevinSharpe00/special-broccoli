package com.mygdx.game;

import java.util.Vector;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class MyGame {

	public Map map;
	Vector<Entity> entities;
	SpriteBatch sb;
	
	public MyGame()
	{
		map = new Map("four");
	}
	
	public MyGame(int i, int j)
	{
		map = new Map(i, j);
	}
	
	/*
	 * adds a building to the specific tile
	 * 
	 * returns true if building is built
	 * returns false is invalid building
	 */
	public boolean AddBuilding(String building, int ipos, int jpos)
	{
		return map.tiles[ipos][jpos].AddBuilding(building);
	}
	
	
	//TODO  need to add texture 
	public boolean AddUnit(double h, double d, int r, Tile p, String c, Texture t)
	{
		Entity ent  = new Entity( h, d, r, p, c, t);
		entities.add(ent);
		return true;
	}
	
	
	/*
	 * prints the map on the console
	 */
	public void MapPrint()
	{
		for(int n = 0; n < map.height; n++)
		{
			for(int m = 0; m < map.length; m++)
			{
				System.out.print(map.tiles[n][m].test);
			}
			System.out.println();
		}
	}
	//added stuff for sprites 
	public void render()
	{
		sb.begin();
		for(int i = 0; i< entities.size(); i++) 
		{
			entities.get(i).sprite.draw(sb);
			entities.get(i).sprite.setPosition(100*i, 100*i);
		}
	    sb.end();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
